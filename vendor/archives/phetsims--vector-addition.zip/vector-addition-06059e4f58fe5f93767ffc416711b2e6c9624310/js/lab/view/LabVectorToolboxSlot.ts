// Copyright 2019-2026, University of Colorado Boulder

/**
 * LabVectorToolboxSlot is a slot in the vector toolbox for the 'Lab' screen. In the Labs screen, each slot
 * corresponds to a vector set, and multiple vectors for that vector set can be dragged to and from the slot.
 *
 * @author Brandon Li
 * @author Chris Malley (PixelZoom, Inc.)
 */

import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import Bounds2 from '../../../../dot/js/Bounds2.js';
import Vector2 from '../../../../dot/js/Vector2.js';
import ModelViewTransform2 from '../../../../phetcommon/js/view/ModelViewTransform2.js';
import Tandem from '../../../../tandem/js/Tandem.js';
import VectorAdditionSceneNode from '../../common/view/VectorAdditionSceneNode.js';
import VectorToolboxSlot from '../../common/view/VectorToolboxSlot.js';
import VectorAdditionFluent from '../../VectorAdditionFluent.js';
import LabVectorSet from '../model/LabVectorSet.js';

// xy-components for the vector icons, in model coordinates.
const ICON_XY_COMPONENTS = Object.freeze<Vector2>( new Vector2( 3.2, 2.5 ) );

// Use identical dilation for mouseArea and touchArea.
const POINTER_AREA_DILATION = Object.freeze<Vector2>( new Vector2( 10, 10 ) );

export default class LabVectorToolboxSlot extends VectorToolboxSlot {

  public constructor( sceneNode: VectorAdditionSceneNode,
                      vectorSet: LabVectorSet,
                      modelViewTransformProperty: TReadOnlyProperty<ModelViewTransform2>,
                      graphBoundsProperty: TReadOnlyProperty<Bounds2>,
                      tandem: Tandem ) {
    super(
      sceneNode,
      vectorSet.allVectors,
      () => vectorSet.getFirstAvailableVector(),
      vectorSet,
      modelViewTransformProperty,
      graphBoundsProperty,
      ICON_XY_COMPONENTS, {
        iconEffectiveWidth: 45,
        mouseAreaDilation: POINTER_AREA_DILATION,
        touchAreaDilation: POINTER_AREA_DILATION,
        symbolProperty: vectorSet.symbolProperty,
        accessibleName: VectorAdditionFluent.a11y.vectorSetButton.accessibleName.createProperty( {
          symbol: vectorSet.accessibleSymbolProperty
        } ),
        accessibleHelpText: VectorAdditionFluent.a11y.vectorSetButton.accessibleHelpText.createProperty( {
          symbol: vectorSet.accessibleSymbolProperty
        } ),
        tandem: tandem
      } );
  }
}
