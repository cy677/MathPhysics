// Copyright 2019-2026, University of Colorado Boulder

/**
 * Explore1DScreenView is the view for the 'Explore 1D' screen.
 *
 * @author Martin Veillette
 */

import affirm from '../../../../perennial-alias/js/browser-and-node/affirm.js';
import Node from '../../../../scenery/js/nodes/Node.js';
import Tandem from '../../../../tandem/js/Tandem.js';
import VectorAdditionConstants from '../../common/VectorAdditionConstants.js';
import ExploreGraphAreaHeading from '../../common/view/ExploreGraphAreaHeading.js';
import ExploreViewProperties from '../../common/view/ExploreViewProperties.js';
import VectorAdditionScreenView from '../../common/view/VectorAdditionScreenView.js';
import Explore1DModel from '../model/Explore1DModel.js';
import Explore1DGraphControlPanel from './Explore1DGraphControlPanel.js';
import Explore1DSceneNode from './Explore1DSceneNode.js';
import Explore1DScreenSummaryContent from './Explore1DScreenSummaryContent.js';
import HorizontalVerticalSceneRadioButtonGroup from './HorizontalVerticalSceneRadioButtonGroup.js';

export default class Explore1DScreenView extends VectorAdditionScreenView {

  // Properties that are specific to the view.
  private readonly viewProperties: ExploreViewProperties;

  public constructor( model: Explore1DModel, tandem: Tandem ) {

    const viewProperties = new ExploreViewProperties( {
      anglesVisiblePropertyInstrumented: false,
      tandem: tandem.createTandem( 'viewProperties' )
    } );

    super( model.sceneProperty, {
      resetModel: () => model.reset(),
      screenSummaryContent: new Explore1DScreenSummaryContent( model.sceneProperty, viewProperties.sumVisibleProperty ),
      tandem: tandem
    } );

    this.viewProperties = viewProperties;

    const graphViewBounds = model.verticalScene.graph.viewBounds;

    // Controls for the graph, at upper right
    const graphControlPanel = new Explore1DGraphControlPanel(
      model.sceneProperty,
      model.horizontalScene,
      model.verticalScene,
      this.viewProperties, {
        right: VectorAdditionConstants.SCREEN_VIEW_BOUNDS.right - VectorAdditionConstants.SCREEN_VIEW_X_MARGIN,
        top: graphViewBounds.top,
        tandem: tandem.createTandem( 'graphControlPanel' )
      } );

    // Radio buttons for selecting a scene, at lower right
    const sceneRadioButtonGroup = new HorizontalVerticalSceneRadioButtonGroup(
      model.sceneProperty,
      model.horizontalScene,
      model.verticalScene, {
        left: graphControlPanel.left,
        bottom: this.resetAllButton.bottom,
        tandem: tandem.createTandem( 'sceneRadioButtonGroup' )
      } );

    // Group scenes under a parent tandem.
    const sceneNodesTandem = tandem.createTandem( 'sceneNodes' );

    const horizonalSceneNode = new Explore1DSceneNode(
      model.horizontalScene,
      model.sceneProperty,
      this.viewProperties,
      model.componentVectorStyleProperty,
      sceneRadioButtonGroup,
      sceneNodesTandem.createTandem( 'horizonalSceneNode' ) );

    const verticalSceneNode = new Explore1DSceneNode(
      model.verticalScene,
      model.sceneProperty,
      this.viewProperties,
      model.componentVectorStyleProperty,
      sceneRadioButtonGroup,
      sceneNodesTandem.createTandem( 'verticalSceneNode' ) );

    // Graph Area heading for the horizontal scene.
    const horizontalGraphAreaHeading = new ExploreGraphAreaHeading(
      horizonalSceneNode.graphNode,
      horizonalSceneNode.vectorSetNodesParent,
      horizonalSceneNode.visibleProperty,
      viewProperties.sumVisibleProperty,
      model.horizontalScene.vectorSet );

    // Graph Area heading for the vertical scene.
    const verticalGraphAreaHeading = new ExploreGraphAreaHeading(
      verticalSceneNode.graphNode,
      verticalSceneNode.vectorSetNodesParent,
      verticalSceneNode.visibleProperty,
      viewProperties.sumVisibleProperty,
      model.verticalScene.vectorSet );

    const screenViewRootNode = new Node( {
      children: [
        // Accessible headings can be put anywhere in rendering order because they have no children. Put them all first.
        horizontalGraphAreaHeading,
        verticalGraphAreaHeading,

        graphControlPanel,
        sceneRadioButtonGroup,
        horizonalSceneNode,
        verticalSceneNode,
        this.resetAllButton
      ]
    } );
    this.addChild( screenViewRootNode );

    // Play Area focus order
    affirm( horizonalSceneNode.eraserButton, 'Expected horizonalSceneNode.eraserButton to be defined.' );
    affirm( verticalSceneNode.eraserButton, 'Expected verticalSceneNode.eraserButton to be defined.' );
    this.pdomPlayAreaNode.pdomOrder = [

      // horizontal scene
      horizontalGraphAreaHeading,
      horizonalSceneNode.vectorToolbox,
      horizonalSceneNode.eraserButton,
      horizonalSceneNode.vectorValuesAccordionBox,

      // vertical scene
      verticalGraphAreaHeading,
      verticalSceneNode.vectorToolbox,
      verticalSceneNode.eraserButton,
      verticalSceneNode.vectorValuesAccordionBox
    ];

    // Control Area focus order
    this.pdomControlAreaNode.pdomOrder = [
      graphControlPanel,
      horizonalSceneNode.originManipulator,
      verticalSceneNode.originManipulator,
      sceneRadioButtonGroup,
      this.resetAllButton
    ];
  }

  public override reset(): void {
    this.viewProperties.reset();
    super.reset();
  }
}
