// Copyright 2019-2026, University of Colorado Boulder

/**
 * The 'Explore 1D' screen.
 *
 * @author Martin Veillette
 */

import Screen, { ScreenOptions } from '../../../joist/js/Screen.js';
import Tandem from '../../../tandem/js/Tandem.js';
import VectorAdditionColors from '../common/VectorAdditionColors.js';
import VectorAdditionIconFactory from '../common/view/VectorAdditionIconFactory.js';
import VectorAdditionKeyboardHelpContent from '../common/view/VectorAdditionKeyboardHelpContent.js';
import VectorAdditionFluent from '../VectorAdditionFluent.js';
import Explore1DModel from './model/Explore1DModel.js';
import Explore1DScreenView from './view/Explore1DScreenView.js';

export default class Explore1DScreen extends Screen<Explore1DModel, Explore1DScreenView> {

  public constructor( tandem: Tandem ) {

    const options: ScreenOptions = {
      name: VectorAdditionFluent.screen.explore1DStringProperty,
      backgroundColorProperty: VectorAdditionColors.screenBackgroundColorProperty,
      homeScreenIcon: VectorAdditionIconFactory.createExplore1DScreenIcon(),
      screenButtonsHelpText: VectorAdditionFluent.a11y.explore1DScreen.screenButtonsHelpTextStringProperty,
      createKeyboardHelpNode: () => new VectorAdditionKeyboardHelpContent(),
      tandem: tandem
    };

    super(
      () => new Explore1DModel( tandem.createTandem( 'model' ) ),
      model => new Explore1DScreenView( model, tandem.createTandem( 'view' ) ),
      options
    );
  }
}
