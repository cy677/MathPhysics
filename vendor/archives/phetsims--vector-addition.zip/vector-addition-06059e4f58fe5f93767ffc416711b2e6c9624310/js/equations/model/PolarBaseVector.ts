// Copyright 2019-2026, University of Colorado Boulder

/**
 * PolarBaseVector is the subclass of BaseVector used with CoordinateSnapMode 'polar'.
 * It creates NumberProperties for the angle and magnitude that are controlled by NumberPickers, and
 * adjusts its xyComponentsProperty based on the values of those Properties.
 *
 * In the Equations screen, magnitudeProperty and angleDegreesProperty are the "ground truth" used to derive
 * the vector's xy-components. xyComponentsProperty cannot be changed via the UI. Changes are made to magnitude and
 * angle individually using NumberPickers.
 *
 * @author Brandon Li
 * @author Chris Malley (PixelZoom, Inc.)
 */

import Multilink from '../../../../axon/js/Multilink.js';
import NumberProperty from '../../../../axon/js/NumberProperty.js';
import Property from '../../../../axon/js/Property.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import { toDegrees } from '../../../../dot/js/util/toDegrees.js';
import { toFixedNumber } from '../../../../dot/js/util/toFixedNumber.js';
import { toRadians } from '../../../../dot/js/util/toRadians.js';
import Vector2 from '../../../../dot/js/Vector2.js';
import affirm from '../../../../perennial-alias/js/browser-and-node/affirm.js';
import optionize, { EmptySelfOptions } from '../../../../phet-core/js/optionize.js';
import { degreesUnit } from '../../../../scenery-phet/js/units/degreesUnit.js';
import isSettingPhetioStateProperty from '../../../../tandem/js/isSettingPhetioStateProperty.js';
import { ComponentVectorStyle } from '../../common/model/ComponentVectorStyle.js';
import Graph from '../../common/model/Graph.js';
import Vector from '../../common/model/Vector.js';
import VectorSet from '../../common/model/VectorSet.js';
import VectorAdditionConstants from '../../common/VectorAdditionConstants.js';
import BaseVector, { BaseVectorOptions } from './BaseVector.js';

type SelfOptions = EmptySelfOptions;

type PolarBaseVectorOptions = SelfOptions & BaseVectorOptions;

export default class PolarBaseVector extends BaseVector {

  // Base vector's magnitude, which can be changed in the Equations screen's polar scene via a NumberPicker.
  // Do not confuse with this._magnitudeProperty which is defined in superclass RootVector and uninstrumented
  // for the Equations screen.
  public readonly magnitudeProperty: NumberProperty;

  // Base vector's angle, which can be changed in the Equations screen's polar scene via a NumberPicker.
  // Do not confuse with this._angleDegreesProperty which is defined in superclass RootVector and uninstrumented
  // for the Equations screen.
  public readonly angleDegreesProperty: NumberProperty;

  public constructor( tailPosition: Vector2,
                      xyComponents: Vector2,
                      vectorSet: VectorSet,
                      graph: Graph,
                      selectedVectorProperty: Property<Vector | null>,
                      componentVectorStyleProperty: TReadOnlyProperty<ComponentVectorStyle>,
                      providedOptions: PolarBaseVectorOptions ) {

    const options = optionize<PolarBaseVectorOptions, SelfOptions, BaseVectorOptions>()( {

      // BaseVectorOptions
      magnitudePropertyInstrumented: false, // because this class defines its own PhET-iO Element named magnitudeProperty
      angleDegreesPropertyInstrumented: false // because this class defines its own PhET-iO Element named angleDegreesProperty
    }, providedOptions );
    affirm( options.coordinateSnapMode === 'polar', `invalid coordinateSnapMode: ${options.coordinateSnapMode}` );

    super( tailPosition, xyComponents, vectorSet, graph, selectedVectorProperty, componentVectorStyleProperty, options );

    this.magnitudeProperty = new NumberProperty( this.magnitude, {
      numberType: 'Integer',
      range: VectorAdditionConstants.MAGNITUDE_RANGE, // zero magnitude is allowed for a base vector
      tandem: options.tandem.createTandem( 'magnitudeProperty' ),
      phetioFeatured: true
    } );

    const initialAngle = this.angle!;
    affirm( initialAngle !== null, 'expected this.angle to be non-null' );
    this.angleDegreesProperty = new NumberProperty( toFixedNumber( toDegrees( initialAngle ), 0 ), {
      numberType: 'Integer',
      range: VectorAdditionConstants.SIGNED_ANGLE_RANGE,
      units: degreesUnit,
      tandem: options.tandem.createTandem( 'angleDegreesProperty' ),
      phetioFeatured: true
    } );

    // When the magnitude or angle changes, update xyComponentsProperty.
    // In the Equations screen, xyComponentsProperty cannot be changed via the UI, so we do not need to listen to it
    // to update this.magnitudeProperty and this.angleDegreesProperty.
    Multilink.multilink(
      [ this.magnitudeProperty, this.angleDegreesProperty ],
      ( magnitude, angleDegrees ) => {
        if ( !isSettingPhetioStateProperty.value ) {
          this.xyComponentsProperty.value = Vector2.createPolar( magnitude, toRadians( angleDegrees ) );
        }
      } );
  }

  public override reset(): void {
    this.magnitudeProperty.reset();
    this.angleDegreesProperty.reset();
    super.reset();
  }
}
