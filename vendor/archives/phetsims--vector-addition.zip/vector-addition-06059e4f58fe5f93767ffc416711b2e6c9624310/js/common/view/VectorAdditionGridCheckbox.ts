// Copyright 2019-2026, University of Colorado Boulder

/**
 * VectorAdditionGridCheckbox is a specialization of common-code GridCheckbox, styled for this sim.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import Property from '../../../../axon/js/Property.js';
import { combineOptions } from '../../../../phet-core/js/optionize.js';
import GridCheckbox, { GridCheckboxOptions } from '../../../../scenery-phet/js/GridCheckbox.js';
import Tandem from '../../../../tandem/js/Tandem.js';
import VectorAdditionFluent from '../../VectorAdditionFluent.js';
import VectorAdditionConstants from '../VectorAdditionConstants.js';

export default class VectorAdditionGridCheckbox extends GridCheckbox {

  public constructor( gridVisibleProperty: Property<boolean>, tandem: Tandem ) {

    const options = combineOptions<GridCheckboxOptions>( {}, VectorAdditionConstants.CHECKBOX_OPTIONS, {
      iconOptions: { size: 24 },
      accessibleName: VectorAdditionFluent.a11y.gridCheckbox.accessibleNameStringProperty,
      accessibleHelpText: VectorAdditionFluent.a11y.gridCheckbox.accessibleHelpTextStringProperty,
      tandem: tandem
    } );

    super( gridVisibleProperty, options );
  }
}
