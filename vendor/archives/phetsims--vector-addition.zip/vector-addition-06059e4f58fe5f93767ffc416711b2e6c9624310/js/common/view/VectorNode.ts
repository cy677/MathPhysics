// Copyright 2019-2026, University of Colorado Boulder

/**
 * VectorNode is the view for the vectors that are dragged onto the graph.
 *
 * @author Martin Veillette
 * @author Chris Malley (PixelZoom, Inc.)
 */

import DerivedProperty from '../../../../axon/js/DerivedProperty.js';
import Multilink from '../../../../axon/js/Multilink.js';
import Property from '../../../../axon/js/Property.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import Bounds2 from '../../../../dot/js/Bounds2.js';
import { toFixedNumber } from '../../../../dot/js/util/toFixedNumber.js';
import affirm from '../../../../perennial-alias/js/browser-and-node/affirm.js';
import { combineOptions, EmptySelfOptions, optionize4 } from '../../../../phet-core/js/optionize.js';
import ModelViewTransform2 from '../../../../phetcommon/js/view/ModelViewTransform2.js';
import AccessibleDraggableOptions from '../../../../scenery-phet/js/accessibility/grab-drag/AccessibleDraggableOptions.js';
import ArrowNode, { ArrowNodeOptions } from '../../../../scenery-phet/js/ArrowNode.js';
import InteractiveHighlighting from '../../../../scenery/js/accessibility/voicing/InteractiveHighlighting.js';
import DragListener from '../../../../scenery/js/listeners/DragListener.js';
import { PressListenerEvent } from '../../../../scenery/js/listeners/PressListener.js';
import Color from '../../../../scenery/js/util/Color.js';
import VectorAdditionFluent from '../../VectorAdditionFluent.js';
import Vector from '../model/Vector.js';
import VectorAdditionConstants from '../VectorAdditionConstants.js';
import CheckVectorValuesKeyboardShortcut from './CheckVectorValuesKeyboardShortcut.js';
import { MoveVectorDragListener } from './MoveVectorDragListener.js';
import MoveVectorKeyboardListener from './MoveVectorKeyboardListener.js';
import RemoveVectorKeyboardListener from './RemoveVectorKeyboardListener.js';
import RootVectorNode, { RootVectorArrowNodeOptions, RootVectorNodeOptions } from './RootVectorNode.js';
import SelectVectorKeyboardListener from './SelectVectorKeyboardListener.js';
import VectorAngleNode from './VectorAngleNode.js';
import VectorTipNode from './VectorTipNode.js';

// options for the vector shadow
const SHADOW_OPTIONS = combineOptions<ArrowNodeOptions>( {}, VectorAdditionConstants.VECTOR_ARROW_OPTIONS, {
  fill: Color.BLACK,
  opacity: 0.28
} );

// offsets for vector shadow in view coordinates
const SHADOW_X_OFFSET = 3.2;
const SHADOW_Y_OFFSET = 2.1;

type SelfOptions = EmptySelfOptions;
export type VectorNodeOptions = SelfOptions & RootVectorNodeOptions;

export default class VectorNode extends InteractiveHighlighting( RootVectorNode ) {

  // The associated vector model element.
  public readonly vector: Vector;

  // Optional tipNode, for vectors that can be scaled and rotated.
  public readonly tipNode?: VectorTipNode;

  // Bounds of the graph.
  private readonly graphBoundsProperty: TReadOnlyProperty<Bounds2>;

  // Drag listener for moving the vector with the pointer, for drag forwarding.
  private readonly moveVectorDragListener: DragListener;

  // Disposes of things that are specific to this class.
  private readonly disposeVectorNode: () => void;

  public constructor( vector: Vector,
                      modelViewTransformProperty: TReadOnlyProperty<ModelViewTransform2>,
                      selectedVectorProperty: Property<Vector | null>,
                      valuesVisibleProperty: TReadOnlyProperty<boolean>,
                      anglesVisibleProperty: TReadOnlyProperty<boolean>,
                      graphBoundsProperty: TReadOnlyProperty<Bounds2>,
                      providedOptions?: VectorNodeOptions ) {

    const accessibleNameProperty = VectorAdditionFluent.a11y.vectorNode.body.accessibleName.createProperty( {
      symbol: vector.accessibleSymbolProperty
    } );

    const options = optionize4<VectorNodeOptions, SelfOptions, RootVectorNodeOptions>()(
      {}, AccessibleDraggableOptions, {

        // RootVectorNodeOptions
        cursor: 'move',
        arrowOptions: combineOptions<RootVectorArrowNodeOptions>(
          {}, VectorAdditionConstants.VECTOR_ARROW_OPTIONS, {
            fill: vector.vectorColorPalette.vectorFillProperty,
            stroke: vector.vectorColorPalette.vectorStrokeProperty
          } ),
        arrowHasInteractiveHighlight: true,
        accessibleName: accessibleNameProperty,
        accessibleHelpText: VectorAdditionFluent.a11y.vectorNode.body.accessibleHelpTextStringProperty
      }, providedOptions );

    // To improve readability
    const headWidth = options.arrowOptions.headWidth!;
    affirm( headWidth !== undefined, 'Expected headWidth to be defined.' );
    const headHeight = options.arrowOptions.headHeight!;
    affirm( headWidth !== undefined, 'Expected headHeight to be defined.' );
    const fractionalHeadHeight = options.arrowOptions.fractionalHeadHeight!;
    affirm( fractionalHeadHeight !== undefined, 'Expected fractionalHeadHeight to be defined.' );

    // Show vector value (magnitude) only when 'Values' is checked and the vector is on the graph.
    // See https://github.com/phetsims/vector-addition/issues/330.
    const valuesVisibleIfOnGraphProperty = DerivedProperty.and( [ valuesVisibleProperty, vector.isOnGraphProperty ] );

    super( vector, modelViewTransformProperty, valuesVisibleIfOnGraphProperty, selectedVectorProperty, options );

    this.vector = vector;
    this.graphBoundsProperty = graphBoundsProperty;

    //----------------------------------------------------------------------------------------
    // Create Nodes
    //----------------------------------------------------------------------------------------

    // Since the tail is (0, 0) for the view, the tip is the delta position of the tip
    const tipDeltaPosition = modelViewTransformProperty.value.modelToViewDelta( vector.xyComponents );

    // Create a Node representing the arc of an angle and the numerical display of the angle.
    // dispose is necessary because it observes anglesVisibleProperty.
    const angleNode = new VectorAngleNode( vector, anglesVisibleProperty, modelViewTransformProperty );

    // Create a shadow for the vector, visible when the vector is being dragged around off the graph.
    const vectorShadowNode = new ArrowNode( 0, 0, tipDeltaPosition.x, tipDeltaPosition.y, SHADOW_OPTIONS );

    // Reconfigure z-layering
    this.setChildren( [ vectorShadowNode, this.arrowNode, angleNode, this.labelNode ] );

    //----------------------------------------------------------------------------------------
    // Handle vector transformation
    //----------------------------------------------------------------------------------------

    // Pointer listener to move the vector.
    this.moveVectorDragListener = new MoveVectorDragListener( vector, this, vectorShadowNode,
      modelViewTransformProperty, selectedVectorProperty, graphBoundsProperty );
    this.addInputListener( this.moveVectorDragListener );

    // Keyboard listener to move the vector.
    const moveVectorKeyboardListener = new MoveVectorKeyboardListener( vector, this );
    this.addInputListener( moveVectorKeyboardListener );

    // Keyboard listener to select the vector.
    const selectVectorKeyboardListener = new SelectVectorKeyboardListener( vector );
    this.addInputListener( selectVectorKeyboardListener );

    // Keyboard listener to remove the vector from the graph and return it to the toolbox.
    let removeVectorKeyboardListener = null;
    if ( vector.isRemovableFromGraph ) {
      removeVectorKeyboardListener = new RemoveVectorKeyboardListener( vector );
      this.addInputListener( removeVectorKeyboardListener );
    }

    // Keyboard shortcut for checking the vector values.
    const checkVectorValuesKeyboardShortcut = new CheckVectorValuesKeyboardShortcut( vector, this );
    this.addInputListener( checkVectorValuesKeyboardShortcut );

    // Optional scaling and rotation by dragging the vector tip.
    if ( vector.isTipDraggable ) {
      this.tipNode = new VectorTipNode( this, modelViewTransformProperty, selectedVectorProperty, graphBoundsProperty,
        headWidth, headHeight, fractionalHeadHeight );
      this.addChild( this.tipNode );
    }

    //----------------------------------------------------------------------------------------
    // Appearance
    //----------------------------------------------------------------------------------------

    // Update the appearance of the vector's shadow. Must be disposed.
    const shadowMultilink = Multilink.multilink(
      [ vector.isOnGraphProperty, this.vector.animateToToolboxProperty, vector.xyComponentsProperty ],
      ( isOnGraph, animateToToolbox, xyComponents ) => {
        vectorShadowNode.visible = ( !isOnGraph && !animateToToolbox );
        vectorShadowNode.resetTransform();
        if ( !isOnGraph && vectorShadowNode.getBounds().isValid() ) {
          vectorShadowNode.left = this.arrowNode.left + SHADOW_X_OFFSET;
          vectorShadowNode.top = this.arrowNode.top + SHADOW_Y_OFFSET;
        }
        const tipDeltaPosition = modelViewTransformProperty.value.modelToViewDelta( xyComponents );
        vectorShadowNode.setTip( tipDeltaPosition.x, tipDeltaPosition.y );
      } );

    // Highlight the vector's label when it is selected. unlink is required on dispose.
    const selectedVectorListener = ( selectedVector: Vector | null ) => {
      this.labelNode.setHighlighted( selectedVector === vector );
    };
    selectedVectorProperty.link( selectedVectorListener );

    // Disable interaction when the vector is animating back to the toolbox, where it will be disposed.
    // unlink is required on dispose.
    const animateBackListener = ( animateBack: boolean ) => {
      if ( animateBack ) {
        this.interruptSubtreeInput();

        // Make the body non-interactive.
        this.cursor = null;
        this.pickable = false;
        this.focusable = false;

        // Make the tip non-interactive.
        if ( this.tipNode ) {
          this.tipNode.cursor = null;
          this.tipNode.pickable = false;
          this.tipNode.focusable = false;
        }
      }
    };
    this.vector.animateToToolboxProperty.lazyLink( animateBackListener );

    this.focusedProperty.lazyLink( focused => {
      if ( focused && vector.isOnGraphProperty.value ) {
        this.describeFocused();
      }
    } );

    this.disposeVectorNode = () => {

      // Dispose of Properties.
      accessibleNameProperty.dispose();
      valuesVisibleIfOnGraphProperty.dispose();

      // Dispose of nodes
      angleNode.dispose();
      this.tipNode && this.tipNode.dispose();

      // Dispose of input listeners.
      this.moveVectorDragListener.dispose();
      moveVectorKeyboardListener.dispose();
      selectVectorKeyboardListener.dispose();
      removeVectorKeyboardListener && removeVectorKeyboardListener.dispose();
      checkVectorValuesKeyboardShortcut.dispose();

      // Dispose of Property listeners
      shadowMultilink.dispose();
      selectedVectorProperty.unlink( selectedVectorListener );
      this.vector.animateToToolboxProperty.unlink( animateBackListener );
    };
  }

  public override dispose(): void {
    this.disposeVectorNode();
    super.dispose();
  }

  /**
   * Forwards an event to translationDragListener. Used for dragging vectors out of the toolbox.
   */
  public forwardEvent( event: PressListenerEvent ): void {
    this.moveVectorDragListener.press( event, this );
  }

  /**
   * Describes the vector when it gets focus.
   */
  private describeFocused(): void {
    this.addAccessibleFocusObjectResponse( this.getVectorPositionResponse() );
  }

  /**
   * Describes the vector when it is moved. The responses are interruptible so that the user is not spammed with
   * information when pressing the arrow keys repeatedly.
   */
  public describeMoved(): void {
    this.addAccessibleObjectResponse( this.getVectorPositionResponse(), {
      interruptible: true,
      alertDelay: 1000
    } );
  }

  /**
   * Gets the response that describes the vector's position.
   */
  private getVectorPositionResponse(): string {

    // If the tip is outside the graph area, the response is different.
    const pattern = this.graphBoundsProperty.value.containsPoint( this.vector.tip ) ?
                    VectorAdditionFluent.a11y.vectorNode.body.accessibleObjectResponse :
                    VectorAdditionFluent.a11y.vectorNode.body.accessibleObjectResponseTipOutsideGraphArea;

    // Both of the possible values for pattern above must have the same placeholders!
    return pattern.format( {
      tailX: toFixedNumber( this.vector.tailX, VectorAdditionConstants.VECTOR_TAIL_DESCRIPTION_DECIMAL_PLACES ),
      tailY: toFixedNumber( this.vector.tailY, VectorAdditionConstants.VECTOR_TAIL_DESCRIPTION_DECIMAL_PLACES ),
      tipX: toFixedNumber( this.vector.tipX, VectorAdditionConstants.VECTOR_TIP_DESCRIPTION_DECIMAL_PLACES ),
      tipY: toFixedNumber( this.vector.tipY, VectorAdditionConstants.VECTOR_TIP_DESCRIPTION_DECIMAL_PLACES )
    } );
  }
}
