// Copyright 2025-2026, University of Colorado Boulder

/**
 * CartesianPolarSceneRadioButtonGroup is a radio button group for switching between Cartesian and polar scenes.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import Property from '../../../../axon/js/Property.js';
import { EmptySelfOptions, optionize4 } from '../../../../phet-core/js/optionize.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import { NodeTranslationOptions } from '../../../../scenery/js/nodes/Node.js';
import RectangularRadioButtonGroup, { RectangularRadioButtonGroupItem, RectangularRadioButtonGroupOptions } from '../../../../sun/js/buttons/RectangularRadioButtonGroup.js';
import VectorAdditionFluent from '../../VectorAdditionFluent.js';
import VectorAdditionScene from '../model/VectorAdditionScene.js';
import VectorColorPalette from '../model/VectorColorPalette.js';
import VectorAdditionConstants from '../VectorAdditionConstants.js';
import VectorAdditionIconFactory from './VectorAdditionIconFactory.js';

type SelfOptions = EmptySelfOptions;

type CartesianPolarRadioButtonGroupOptions = SelfOptions & NodeTranslationOptions &
  PickRequired<RectangularRadioButtonGroupOptions, 'tandem'>;

export default class CartesianPolarSceneRadioButtonGroup<T extends VectorAdditionScene> extends RectangularRadioButtonGroup<T> {

  public constructor( sceneProperty: Property<T>,
                      cartesianScene: T,
                      cartesianColorPalette: VectorColorPalette,
                      polarScene: T,
                      polarColorPalette: VectorColorPalette,
                      providedOptions: CartesianPolarRadioButtonGroupOptions ) {

    const options = optionize4<CartesianPolarRadioButtonGroupOptions, SelfOptions, RectangularRadioButtonGroupOptions>()(
      {}, VectorAdditionConstants.RADIO_BUTTON_GROUP_OPTIONS, {

        // RectangularRadioButtonGroupOptions
        isDisposable: false,
        accessibleName: VectorAdditionFluent.a11y.cartesianPolarSceneRadioButtonGroup.accessibleNameStringProperty,
        accessibleHelpText: VectorAdditionFluent.a11y.cartesianPolarSceneRadioButtonGroup.accessibleHelpText.createProperty( {
          polarAngleInterval: VectorAdditionConstants.POLAR_ANGLE_INTERVAL
        } )
      }, providedOptions );

    const items: RectangularRadioButtonGroupItem<T>[] = [
      {
        value: cartesianScene,
        createNode: () => VectorAdditionIconFactory.createCartesianSceneIcon( cartesianColorPalette ),
        tandemName: 'cartesianRadioButton',
        options: {
          accessibleName: VectorAdditionFluent.a11y.cartesianRadioButton.accessibleNameStringProperty
        }
      },
      {
        value: polarScene,
        createNode: () => VectorAdditionIconFactory.createPolarSceneIcon( polarColorPalette ),
        tandemName: 'polarRadioButton',
        options: {
          accessibleName: VectorAdditionFluent.a11y.polarRadioButton.accessibleNameStringProperty
        }
      }
    ];

    super( sceneProperty, items, options );
  }
}
