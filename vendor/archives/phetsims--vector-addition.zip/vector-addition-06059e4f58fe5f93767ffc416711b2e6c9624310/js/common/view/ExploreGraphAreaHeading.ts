// Copyright 2025-2026, University of Colorado Boulder

/**
 * ExploreGraphAreaHeading is a 'Graph Area' heading for the Explore 1D and Explore 2D screens.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import DerivedProperty from '../../../../axon/js/DerivedProperty.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import Node from '../../../../scenery/js/nodes/Node.js';
import VectorAdditionFluent from '../../VectorAdditionFluent.js';
import VectorSet from '../model/VectorSet.js';

export default class ExploreGraphAreaHeading extends Node {

  public constructor( graphNode: Node, vectorSetNodesParent: Node, visibleProperty: TReadOnlyProperty<boolean>,
                      sumVisibleProperty: TReadOnlyProperty<boolean>, vectorSet: VectorSet ) {
    super( {
      visibleProperty: visibleProperty,
      pdomOrder: [
        graphNode,
        vectorSetNodesParent
      ],
      accessibleHeading: VectorAdditionFluent.a11y.accessibleHeadings.graphAreaHeadingStringProperty,
      accessibleParagraph: VectorAdditionFluent.a11y.graphArea.accessibleParagraphExplore.createProperty( {
        numberOfVectors: ExploreGraphAreaHeading.createTotalNumberOfVectorsProperty( sumVisibleProperty, vectorSet )
      } )
    } );
  }

  /**
   * Creates a Property that indicates the total number of vectors on the graph for a specified vector set,
   * including the sum vector if it is visible and defined.
   */
  public static createTotalNumberOfVectorsProperty(
    sumVisibleProperty: TReadOnlyProperty<boolean>,
    vectorSet: VectorSet ): TReadOnlyProperty<number> {
    return new DerivedProperty(
      [ sumVisibleProperty, vectorSet.resultantVector.isDefinedProperty, vectorSet.numberOfVectorsOnGraphProperty ],
      ( sumVisible, sumIsDefined, numberOfVectorsOnGraph ) =>
        ( sumVisible && sumIsDefined ) ? numberOfVectorsOnGraph + 1 : numberOfVectorsOnGraph );
  }
}
