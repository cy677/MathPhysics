// Copyright 2025-2026, University of Colorado Boulder

/**
 * VectorToolboxSlot is the base class for a slot in a vector toolbox.
 * A slot contains one or more vectors. Clicking on a slot moves a vector out of the toolbox.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import Bounds2 from '../../../../dot/js/Bounds2.js';
import Vector2 from '../../../../dot/js/Vector2.js';
import affirm from '../../../../perennial-alias/js/browser-and-node/affirm.js';
import optionize from '../../../../phet-core/js/optionize.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import ModelViewTransform2 from '../../../../phetcommon/js/view/ModelViewTransform2.js';
import SoundDragListener from '../../../../scenery-phet/js/SoundDragListener.js';
import ParallelDOM from '../../../../scenery/js/accessibility/pdom/ParallelDOM.js';
import InteractiveHighlighting from '../../../../scenery/js/accessibility/voicing/InteractiveHighlighting.js';
import AlignBox from '../../../../scenery/js/layout/nodes/AlignBox.js';
import HBox, { HBoxOptions } from '../../../../scenery/js/layout/nodes/HBox.js';
import VectorAdditionFluent from '../../VectorAdditionFluent.js';
import Vector from '../model/Vector.js';
import VectorSet from '../model/VectorSet.js';
import AddVectorKeyboardListener from './AddVectorKeyboardListener.js';
import ArrowOverSymbolNode from './ArrowOverSymbolNode.js';
import VectorAdditionIconFactory from './VectorAdditionIconFactory.js';
import VectorAdditionSceneNode from './VectorAdditionSceneNode.js';

type SelfOptions = {
  mouseAreaDilation: Vector2;
  touchAreaDilation: Vector2;

  // The width of an AlignBox bounds, so that the icon and label are aligned consistently regardless of icon size.
  iconEffectiveWidth: number;
  symbolProperty: TReadOnlyProperty<string>;
};

export type VectorToolboxSlotOptions = SelfOptions & PickRequired<HBoxOptions, 'tandem' | 'accessibleName' | 'accessibleHelpText'>;

export default class VectorToolboxSlot extends InteractiveHighlighting( HBox ) {

  protected constructor( sceneNode: VectorAdditionSceneNode,
                         vectors: Vector[], // vectors in the slot
                         getNextVector: () => Vector | null, // Gets the next available vector in the slot.
                         vectorSet: VectorSet,
                         modelViewTransformProperty: TReadOnlyProperty<ModelViewTransform2>,
                         graphBoundsProperty: TReadOnlyProperty<Bounds2>,
                         iconModelComponents: Vector2,
                         providedOptions: VectorToolboxSlotOptions ) {

    // Get the icon's xy-components in view coordinates.
    const iconViewComponents = modelViewTransformProperty.value.modelToViewDelta( iconModelComponents );

    // Create the vector icon.
    const iconNode = VectorAdditionIconFactory.createVectorToolboxIcon( iconViewComponents, vectorSet.vectorColorPalette );

    // Create a fixed-size box for the icon. The icon is placed in an AlignBox to ensure the icon
    // has the same effective width regardless of the initial icon's xy-components. This ensures that
    // the label of the slot is in the same place regardless of the icon size.
    const alignBox = new AlignBox( iconNode, {
      alignBounds: new Bounds2( 0, 0, providedOptions.iconEffectiveWidth, iconNode.height )
    } );

    // Label for the slot, always visible.
    const arrowOverSymbolNode = new ArrowOverSymbolNode( providedOptions.symbolProperty );

    const options = optionize<VectorToolboxSlotOptions, SelfOptions, HBoxOptions>()( {

      // HBoxOptions
      isDisposable: false,
      children: [ alignBox, arrowOverSymbolNode ],
      excludeInvisibleChildrenFromBounds: false,
      tagName: 'button',
      accessibleHelpTextBehavior: ParallelDOM.HELP_TEXT_AFTER_CONTENT,
      cursor: 'move',
      spacing: 5,
      phetioFeatured: true,
      visiblePropertyOptions: {
        phetioFeatured: true
      },
      phetioInputEnabledPropertyInstrumented: true
    }, providedOptions );

    super( options );

    // Make the vector easier to grab.
    this.mouseArea = this.localBounds.dilatedXY( providedOptions.mouseAreaDilation.x, providedOptions.mouseAreaDilation.y );
    this.touchArea = this.localBounds.dilatedXY( providedOptions.touchAreaDilation.x, providedOptions.touchAreaDilation.y );

    // Drag a vector out of the slot using the pointer.
    this.addInputListener( SoundDragListener.createForwardingListener( event => {
      const vector = getNextVector();
      if ( vector ) {
        vector.reset();

        // Find where the icon was clicked relative to the scene node, in view coordinates.
        const vectorCenterView = sceneNode.globalToLocalPoint( event.pointer.point );

        // Convert the view coordinates of where the icon was clicked into model coordinates.
        const vectorCenterModel = modelViewTransformProperty.value.viewToModelPosition( vectorCenterView );

        // Set the tail position such that the pointer cursor ends up at the center of the vector.
        vector.tailPositionProperty.value = vectorCenterModel.minus( vector.xyComponents.timesScalar( 0.5 ) );

        // Add to activeVectors, so that it is included in the sum calculation when dropped on the graph.
        vectorSet.activeVectors.push( vector );

        // Tell sceneNode to create the view for the vector.
        sceneNode.registerVector( vector, vectorSet, event );
      }
    } ) );

    // Add a vector to the graph using the keyboard.
    this.addInputListener( new AddVectorKeyboardListener( getNextVector, vectorSet, sceneNode, graphBoundsProperty ) );

    // When the slot is empty...
    vectorSet.activeVectors.lengthProperty.link( () => {
      const slotIsEmpty = _.every( vectors, vector => vectorSet.activeVectors.includes( vector ) );
      iconNode.opacity = slotIsEmpty ? 0 : 1; // Workaround: hiding the icon causes the size of the focus highlight to change.
      this.pickable = !slotIsEmpty;

      // Use a11y design pattern similar to the buckets in Build an Atom.
      // See https://github.com/phetsims/vector-addition/issues/427.
      this.setPDOMAttribute( 'aria-disabled', slotIsEmpty );
      if ( slotIsEmpty ) {
        this.setAccessibleHelpText( VectorAdditionFluent.a11y.vectorSetButton.accessibleHelpTextEmptyStringProperty );
      }
      else {
        this.setAccessibleHelpText( options.accessibleHelpText );
      }
    } );

    // When a vector from this slot is added to activeVectors, add the listener that handles animating it back to the slot.
    vectorSet.activeVectors.addItemAddedListener( vector => {

      if ( vectors.includes( vector ) ) {

        const animateToToolboxListener = ( animateBack: boolean ) => {
          if ( animateBack ) {

            // Get the model position of the icon node.
            const iconPosition = modelViewTransformProperty.value.viewToModelBounds( sceneNode.boundsOf( iconNode ) ).center;

            // Animate the vector to its icon in the panel.
            vector.animateToPoint( iconPosition, iconModelComponents, () => vector.returnToToolbox() );
          }
        };
        affirm( !vector.animateToToolboxProperty.hasListener( animateToToolboxListener ),
          `vector ${vector.accessibleSymbolProperty.value} animateToToolboxProperty already has animateToToolboxListener.` );
        vector.animateToToolboxProperty.link( animateToToolboxListener ); // unlink required when vector is removed

        // Clean up when the vector is removed from activeVectors.
        const vectorRemovedListener = ( removedVector: Vector ) => {
          if ( removedVector === vector ) {
            vector.animateToToolboxProperty.value = false;
            vector.animateToToolboxProperty.unlink( animateToToolboxListener );
            vectorSet.activeVectors.removeItemRemovedListener( vectorRemovedListener );
          }
        };
        vectorSet.activeVectors.addItemRemovedListener( vectorRemovedListener );
      }
    } );
  }
}
