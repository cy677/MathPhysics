// Copyright 2019-2026, University of Colorado Boulder

/**
 * VectorAdditionScene is the base class for scenes, intended to be subclassed. A screen can have multiple scenes.
 *
 * A scene is responsible for:
 *   - Keeping track of where the origin is dragged and updating a modelViewTransformProperty.
 *   - Keeping track of the selected vector on the graph.
 *   - Managing one or more VectorSets.
 *   - Creating the scene.
 *
 * @author Brandon Li
 * @author Chris Malley (PixelZoom, Inc.)
 */

import Property from '../../../../axon/js/Property.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import optionize, { combineOptions } from '../../../../phet-core/js/optionize.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import StrictOmit from '../../../../phet-core/js/types/StrictOmit.js';
import PhetioObject, { PhetioObjectOptions } from '../../../../tandem/js/PhetioObject.js';
import IOType from '../../../../tandem/js/types/IOType.js';
import NullableIO from '../../../../tandem/js/types/NullableIO.js';
import ReferenceIO, { ReferenceIOState } from '../../../../tandem/js/types/ReferenceIO.js';
import { CoordinateSnapMode } from './CoordinateSnapMode.js';
import Graph, { GraphOptions } from './Graph.js';
import Vector from './Vector.js';
import VectorSet from './VectorSet.js';

type SelfOptions = {

  // Options that are propagated to the scene's Graph instance.
  // This is an option so that the caller can override one or more default values.
  graphOptions: StrictOmit<GraphOptions, 'tandem'>;
};

type VectorAdditionSceneOptions = SelfOptions & PickRequired<PhetioObjectOptions, 'tandem'>;

export default class VectorAdditionScene extends PhetioObject {

  // The scene's name, as used in interactive descriptions. It does not appear in the visual UI.
  public readonly accessibleSceneNameStringProperty: TReadOnlyProperty<string>;

  // coordinate snap mode for the scene, Cartesian or polar
  public readonly coordinateSnapMode: CoordinateSnapMode;

  // the vectorSets for this scene, added by the subclass
  public readonly vectorSets: VectorSet[];

  // the graph for this scene
  public readonly graph: Graph;

  // The selected vector. A scene has at most one selected vector. If null, there is no selected vector.
  public readonly selectedVectorProperty: Property<Vector | null>;

  protected constructor( accessibleSceneNameStringProperty: TReadOnlyProperty<string>,
                         coordinateSnapMode: CoordinateSnapMode,
                         providedOptions: VectorAdditionSceneOptions ) {

    const options = optionize<VectorAdditionSceneOptions, SelfOptions, PhetioObjectOptions>()( {

      // PhetioObjectOptions
      isDisposable: false,
      phetioState: false, // because VectorAdditionSceneIO implements reference-type serialization.
      phetioType: VectorAdditionScene.VectorAdditionSceneIO
    }, providedOptions );

    super( options );

    this.accessibleSceneNameStringProperty = accessibleSceneNameStringProperty;
    this.coordinateSnapMode = coordinateSnapMode;

    this.vectorSets = [];

    this.graph = new Graph( combineOptions<GraphOptions>( {
      tandem: options.tandem.createTandem( 'graph' )
    }, options.graphOptions ) );

    this.selectedVectorProperty = new Property<Vector | null>( null, {
      phetioValueType: NullableIO( Vector.VectorIO ),
      tandem: options.tandem.createTandem( 'selectedVectorProperty' ),
      phetioDocumentation: 'The selected vector on the graph.',
      phetioFeatured: true,
      phetioReadOnly: true
    } );
  }

  public reset(): void {
    this.graph.reset();
    this.selectedVectorProperty.reset();
    this.vectorSets.forEach( vectorSet => vectorSet.reset() );
  }

  /**
   * Erases vectors from the scene.
   */
  public erase(): void {
    this.selectedVectorProperty.reset();
    this.vectorSets.forEach( vectorSet => vectorSet.erase() );
  }

  /**
   * VectorAdditionSceneIO handles serialization of a VectorAdditionScene. It implements reference-type serialization, as
   * described in https://github.com/phetsims/phet-io/blob/main/doc/phet-io-instrumentation-technical-guide.md#serialization.
   */
  public static readonly VectorAdditionSceneIO = new IOType<VectorAdditionScene, ReferenceIOState>( 'VectorAdditionSceneIO', {
    valueType: VectorAdditionScene,
    supertype: ReferenceIO( IOType.ObjectIO )
  } );
}
