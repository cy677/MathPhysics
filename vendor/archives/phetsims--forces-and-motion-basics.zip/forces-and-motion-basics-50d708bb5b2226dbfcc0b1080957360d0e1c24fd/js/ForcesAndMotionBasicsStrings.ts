// Copyright 2021-2026, University of Colorado Boulder

/* eslint-disable */
/* @formatter:off */

/**
 * Auto-generated from modulify, DO NOT manually modify.
 */

import getStringModule from '../../chipper/js/browser/getStringModule.js';
import type LocalizedStringProperty from '../../chipper/js/browser/LocalizedStringProperty.js';
import forcesAndMotionBasics from './forcesAndMotionBasics.js';

type StringsType = {
  'noneStringProperty': LocalizedStringProperty;
  'forceStringProperty': LocalizedStringProperty;
  'valuesStringProperty': LocalizedStringProperty;
  'redWinsStringProperty': LocalizedStringProperty;
  'frictionForceStringProperty': LocalizedStringProperty;
  'pauseStringProperty': LocalizedStringProperty;
  'frictionStringProperty': LocalizedStringProperty;
  'forces-and-motion-basics': {
    'titleStringProperty': LocalizedStringProperty;
  };
  'leftForceStringProperty': LocalizedStringProperty;
  'appliedForceStringProperty': LocalizedStringProperty;
  'rightForceStringProperty': LocalizedStringProperty;
  'pattern': {
    '0massUnitsKilogramsStringProperty': LocalizedStringProperty;
    '0valueUnitsNewtonsStringProperty': LocalizedStringProperty;
    '0name': {
      '1valueUnitsAccelerationStringProperty': LocalizedStringProperty;
      '1valueUnitsVelocityStringProperty': LocalizedStringProperty;
    };
    '0valueUnitsNStringProperty': LocalizedStringProperty;
  };
  'accelerationStringProperty': LocalizedStringProperty;
  'lotsStringProperty': LocalizedStringProperty;
  'forcesStringProperty': LocalizedStringProperty;
  'netForceStringProperty': LocalizedStringProperty;
  'motionStringProperty': LocalizedStringProperty;
  'goStringProperty': LocalizedStringProperty;
  'sumOfForcesEqualsZeroStringProperty': LocalizedStringProperty;
  'blueWinsStringProperty': LocalizedStringProperty;
  'sumOfForcesStringProperty': LocalizedStringProperty;
  'speedStringProperty': LocalizedStringProperty;
  'stopwatchStringProperty': LocalizedStringProperty;
  'returnStringProperty': LocalizedStringProperty;
  'massesStringProperty': LocalizedStringProperty;
  'unknownValueIndicatorStringProperty': LocalizedStringProperty;
  'netForcePullerColorsStringProperty': LocalizedStringProperty;
  'blueAndRedStringProperty': LocalizedStringProperty;
  'purpleAndOrangeStringProperty': LocalizedStringProperty;
  'purpleWinsStringProperty': LocalizedStringProperty;
  'orangeWinsStringProperty': LocalizedStringProperty;
  'keyboardHelpDialog': {
    'fromAnywhereInScreenStringProperty': LocalizedStringProperty;
    'startGameStringProperty': LocalizedStringProperty;
    'pauseGameStringProperty': LocalizedStringProperty;
    'returnCartToCenterStringProperty': LocalizedStringProperty;
    'pullerNavigationStringProperty': LocalizedStringProperty;
    'selectPullerStringProperty': LocalizedStringProperty;
    'grabPullerStringProperty': LocalizedStringProperty;
    'moveGrabbedPullerStringProperty': LocalizedStringProperty;
    'dropPullerStringProperty': LocalizedStringProperty;
    'objectNavigationStringProperty': LocalizedStringProperty;
    'selectObjectStringProperty': LocalizedStringProperty;
    'grabObjectStringProperty': LocalizedStringProperty;
    'moveGrabbedObjectStringProperty': LocalizedStringProperty;
    'dropObjectStringProperty': LocalizedStringProperty;
    'adjustAppliedForceStringProperty': LocalizedStringProperty;
    'zeroAppliedForceStringProperty': LocalizedStringProperty;
    'returnToToolboxStringProperty': LocalizedStringProperty;
    'cancelMovementStringProperty': LocalizedStringProperty;
  };
  'a11y': {
    'navigableStringProperty': LocalizedStringProperty;
    'sortableStringProperty': LocalizedStringProperty;
    'valuesCheckbox': {
      'checkedResponseStringProperty': LocalizedStringProperty;
      'uncheckedResponseStringProperty': LocalizedStringProperty;
      'accessibleHelpTextForceStringProperty': LocalizedStringProperty;
      'accessibleHelpTextForceSpeedStringProperty': LocalizedStringProperty;
      'accessibleHelpTextForceSpeedAccelerationStringProperty': LocalizedStringProperty;
    };
    'speedCheckbox': {
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
      'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
    };
    'preferences': {
      'netForcePullerColorControl': {
        'accessibleHelpTextStringProperty': LocalizedStringProperty;
      }
    };
    'netForceScreen': {
      'screenButtonsHelpTextStringProperty': LocalizedStringProperty;
      'colorNameStringProperty': LocalizedStringProperty;
      'teamNameStringProperty': LocalizedStringProperty;
      'screenSummary': {
        'playArea': {
          'descriptionStringProperty': LocalizedStringProperty;
        };
        'controlArea': {
          'descriptionStringProperty': LocalizedStringProperty;
        };
        'currentDetails': {
          'accessibleNameNotStartedStringProperty': LocalizedStringProperty;
          'accessibleNameInProgressStringProperty': LocalizedStringProperty;
          'accessibleNameCompletedStringProperty': LocalizedStringProperty;
          'noPullersAttachedStringProperty': LocalizedStringProperty;
          'teamAttachedStringProperty': LocalizedStringProperty;
        };
        'interactionHintStringProperty': LocalizedStringProperty;
      };
      'puller': {
        'accessibleNameStringProperty': LocalizedStringProperty;
        'accessibleRoleDescriptionStringProperty': LocalizedStringProperty;
        'sizeStringProperty': LocalizedStringProperty;
      };
      'pullerGroup': {
        'accessibleRoleDescriptionStringProperty': LocalizedStringProperty;
      };
      'pullerResponses': {
        'pullerAttachedToKnotStringProperty': LocalizedStringProperty;
        'pullerReturnedToToolboxStringProperty': LocalizedStringProperty;
        'pullerInteractionCancelledStringProperty': LocalizedStringProperty;
      };
      'returnButton': {
        'cartReturnedToCenterStringProperty': LocalizedStringProperty;
        'accessibleNameStringProperty': LocalizedStringProperty;
        'accessibleHelpTextStringProperty': LocalizedStringProperty;
      };
      'goPauseButton': {
        'accessibleHelpTextGoStringProperty': LocalizedStringProperty;
        'accessibleHelpTextPauseStringProperty': LocalizedStringProperty;
        'cartMovingLeftStringProperty': LocalizedStringProperty;
        'cartMovingRightStringProperty': LocalizedStringProperty;
        'cartStationaryStringProperty': LocalizedStringProperty;
        'cartPausedStringProperty': LocalizedStringProperty;
      };
      'netForceControlPanel': {
        'sumOfForces': {
          'accessibleHelpTextStringProperty': LocalizedStringProperty;
          'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
        }
      };
      'playAreaControls': {
        'accessibleHeadingStringProperty': LocalizedStringProperty;
      }
    };
    'motionScreen': {
      'motionScreenButtonsHelpTextStringProperty': LocalizedStringProperty;
      'frictionScreenButtonsHelpTextStringProperty': LocalizedStringProperty;
      'accelerationScreenButtonsHelpTextStringProperty': LocalizedStringProperty;
      'screenSummary': {
        'playArea': {
          'motionDescriptionStringProperty': LocalizedStringProperty;
          'frictionDescriptionStringProperty': LocalizedStringProperty;
          'accelerationDescriptionStringProperty': LocalizedStringProperty;
        };
        'controlArea': {
          'motionDescriptionStringProperty': LocalizedStringProperty;
          'frictionDescriptionStringProperty': LocalizedStringProperty;
          'accelerationDescriptionStringProperty': LocalizedStringProperty;
        };
        'currentDetails': {
          'summaryStringProperty': LocalizedStringProperty;
        };
        'interactionHintStringProperty': LocalizedStringProperty;
      };
      'stackMovement': {
        'stackMovingLeftStringProperty': LocalizedStringProperty;
        'stackMovingRightStringProperty': LocalizedStringProperty;
        'stackStationaryStringProperty': LocalizedStringProperty;
      };
      'stackState': {
        'stationaryStringProperty': LocalizedStringProperty;
        'movingRightStringProperty': LocalizedStringProperty;
        'movingLeftStringProperty': LocalizedStringProperty;
      };
      'objects': {
        'objectAccessibleNameWithMassStringProperty': LocalizedStringProperty;
        'massUnknownStringProperty': LocalizedStringProperty;
        'names': {
          'fridgeStringProperty': LocalizedStringProperty;
          'crate1StringProperty': LocalizedStringProperty;
          'crate2StringProperty': LocalizedStringProperty;
          'girlStringProperty': LocalizedStringProperty;
          'manStringProperty': LocalizedStringProperty;
          'trashStringProperty': LocalizedStringProperty;
          'mysteryStringProperty': LocalizedStringProperty;
          'bucketStringProperty': LocalizedStringProperty;
        }
      };
      'objectToolbox': {
        'accessibleNameStringProperty': LocalizedStringProperty;
        'accessibleRoleDescriptionStringProperty': LocalizedStringProperty;
        'descriptionContentStringProperty': LocalizedStringProperty;
      };
      'objectStackGroup': {
        'onSkateboard': {
          'accessibleNameStringProperty': LocalizedStringProperty;
        };
        'onGround': {
          'accessibleNameStringProperty': LocalizedStringProperty;
        };
        'accessibleRoleDescriptionStringProperty': LocalizedStringProperty;
        'descriptionContentStringProperty': LocalizedStringProperty;
      };
      'objectResponses': {
        'overToolboxStringProperty': LocalizedStringProperty;
        'overStackStringProperty': LocalizedStringProperty;
        'overSkateboardStringProperty': LocalizedStringProperty;
        'overGroundStringProperty': LocalizedStringProperty;
        'droppedOnStackStringProperty': LocalizedStringProperty;
        'droppedOnStackBottomObjectReturnedStringProperty': LocalizedStringProperty;
        'droppedOnSkateboardStringProperty': LocalizedStringProperty;
        'droppedOnGroundStringProperty': LocalizedStringProperty;
        'returnedToToolboxStringProperty': LocalizedStringProperty;
        'returnedToStackStringProperty': LocalizedStringProperty;
      };
      'surface': {
        'skateboardStringProperty': LocalizedStringProperty;
        'groundStringProperty': LocalizedStringProperty;
      };
      'stackList': {
        'stackedOnSurfaceStringProperty': LocalizedStringProperty;
        'noObjectsOnSurfaceStringProperty': LocalizedStringProperty;
      };
      'pusherResponses': {
        'fellDownAppliedForceZeroStringProperty': LocalizedStringProperty;
      };
      'motionControlPanel': {
        'forceCheckbox': {
          'accessibleHelpTextStringProperty': LocalizedStringProperty;
          'accessibleContextResponseCheckedStringProperty': LocalizedStringProperty;
          'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
        };
        'massesCheckbox': {
          'accessibleHelpTextStringProperty': LocalizedStringProperty;
          'accessibleContextResponseCheckedStringProperty': LocalizedStringProperty;
          'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
        };
        'stopwatchCheckbox': {
          'accessibleHelpTextStringProperty': LocalizedStringProperty;
          'accessibleContextResponseCheckedStringProperty': LocalizedStringProperty;
          'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
        };
        'forcesCheckbox': {
          'accessibleHelpTextStringProperty': LocalizedStringProperty;
          'accessibleContextResponseCheckedStringProperty': LocalizedStringProperty;
          'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
        };
        'sumOfForcesCheckbox': {
          'accessibleHelpTextStringProperty': LocalizedStringProperty;
          'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
        };
        'accelerationCheckbox': {
          'accessibleHelpTextStringProperty': LocalizedStringProperty;
          'accessibleContextResponseUncheckedStringProperty': LocalizedStringProperty;
        }
      };
      'playAreaControls': {
        'appliedForceControl': {
          'accessibleHeadingStringProperty': LocalizedStringProperty;
          'descriptionStringProperty': LocalizedStringProperty;
        }
      };
      'frictionSlider': {
        'accessibleHelpTextStringProperty': LocalizedStringProperty;
        'contextResponse': {
          'smootherStringProperty': LocalizedStringProperty;
          'rougherStringProperty': LocalizedStringProperty;
          'icyStringProperty': LocalizedStringProperty;
        }
      }
    };
    'objectToolboxes': {
      'objectToolboxStringProperty': LocalizedStringProperty;
      'skateboardStringProperty': LocalizedStringProperty;
      'stackStringProperty': LocalizedStringProperty;
    };
    'pullers': {
      'pullerInstructionStringProperty': LocalizedStringProperty;
      'overReturnToToolboxStringProperty': LocalizedStringProperty;
      'overKnotDescriptionStringProperty': LocalizedStringProperty;
      'knotDescriptionStringProperty': LocalizedStringProperty;
      'leftSideStringProperty': LocalizedStringProperty;
      'rightSideStringProperty': LocalizedStringProperty;
    };
    'tugOfWar': {
      'headingStringProperty': LocalizedStringProperty;
      'list': {
        'leadingParagraphStringProperty': LocalizedStringProperty;
      };
      'noPullersOnRopeStringProperty': LocalizedStringProperty;
      'knotOccupiedStringProperty': LocalizedStringProperty;
    };
    'forces': {
      'netForceScreenHeadingStringProperty': LocalizedStringProperty;
      'motionScreensHeadingStringProperty': LocalizedStringProperty;
      'appliedForceArrowStringProperty': LocalizedStringProperty;
      'frictionForceArrowStringProperty': LocalizedStringProperty;
      'leftForceArrowStringProperty': LocalizedStringProperty;
      'rightForceArrowStringProperty': LocalizedStringProperty;
      'sumOfForcesArrowStringProperty': LocalizedStringProperty;
      'sumOfForcesZeroStringProperty': LocalizedStringProperty;
      'noForcesDisplayedStringProperty': LocalizedStringProperty;
      'quantitativeDescriptionStringProperty': LocalizedStringProperty;
      'qualitativeDescriptions': {
        'verySmallStringProperty': LocalizedStringProperty;
        'smallStringProperty': LocalizedStringProperty;
        'mediumStringProperty': LocalizedStringProperty;
        'somewhatLargeStringProperty': LocalizedStringProperty;
        'largeStringProperty': LocalizedStringProperty;
        'veryLargeStringProperty': LocalizedStringProperty;
        'extremelyLargeStringProperty': LocalizedStringProperty;
        'leftStringProperty': LocalizedStringProperty;
        'rightStringProperty': LocalizedStringProperty;
      }
    };
    'speed': {
      'headingStringProperty': LocalizedStringProperty;
      'cartSpeedStringProperty': LocalizedStringProperty;
      'cartSpeedWithAccelerationStringProperty': LocalizedStringProperty;
      'speedOnlyStringProperty': LocalizedStringProperty;
      'speedOnlyWithAccelerationStringProperty': LocalizedStringProperty;
      'speedWithValueStringProperty': LocalizedStringProperty;
      'speedWithValueAndAccelerationStringProperty': LocalizedStringProperty;
      'qualitativeDescriptions': {
        'stationaryStringProperty': LocalizedStringProperty;
        'verySlowStringProperty': LocalizedStringProperty;
        'slowStringProperty': LocalizedStringProperty;
        'moderateStringProperty': LocalizedStringProperty;
        'fastStringProperty': LocalizedStringProperty;
        'veryFastStringProperty': LocalizedStringProperty;
        'extremelyFastStringProperty': LocalizedStringProperty;
      }
    };
    'acceleration': {
      'headingStringProperty': LocalizedStringProperty;
      'accelerationOnlyStringProperty': LocalizedStringProperty;
      'accelerationWithValueStringProperty': LocalizedStringProperty;
      'accelerationWithDirectionStringProperty': LocalizedStringProperty;
      'accelerationWithDirectionAndValueStringProperty': LocalizedStringProperty;
      'qualitativeDescriptions': {
        'zeroStringProperty': LocalizedStringProperty;
        'verySmallStringProperty': LocalizedStringProperty;
        'smallStringProperty': LocalizedStringProperty;
        'moderateStringProperty': LocalizedStringProperty;
        'largeStringProperty': LocalizedStringProperty;
        'veryLargeStringProperty': LocalizedStringProperty;
        'extremelyLargeStringProperty': LocalizedStringProperty;
        'leftStringProperty': LocalizedStringProperty;
        'rightStringProperty': LocalizedStringProperty;
      };
      'accelerationDescriptions': {
        'speedingUpStringProperty': LocalizedStringProperty;
        'slowingDownStringProperty': LocalizedStringProperty;
      }
    }
  }
};

const ForcesAndMotionBasicsStrings = getStringModule( 'FORCES_AND_MOTION_BASICS' ) as StringsType;

forcesAndMotionBasics.register( 'ForcesAndMotionBasicsStrings', ForcesAndMotionBasicsStrings );

export default ForcesAndMotionBasicsStrings;
