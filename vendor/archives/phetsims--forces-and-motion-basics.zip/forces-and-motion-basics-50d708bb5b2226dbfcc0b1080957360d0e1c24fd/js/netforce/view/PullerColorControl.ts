// Copyright 2024-2026, University of Colorado Boulder

/**
 * PullerColorControl is the control used to choose the colors of the pushers and pullers in the Net Force screen.
 * The user can change the colors, but they will revert back to the default on a reset. This control is
 * intended to appear in the Preferences dialog.
 *
 * @author Luisa Vargas (PhET Interactive Simulations)
 */

import StringUnionProperty from '../../../../axon/js/StringUnionProperty.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import PreferencesDialogConstants from '../../../../joist/js/preferences/PreferencesDialogConstants.js';
import VBox from '../../../../scenery/js/layout/nodes/VBox.js';
import Text from '../../../../scenery/js/nodes/Text.js';
import VerticalAquaRadioButtonGroup from '../../../../sun/js/VerticalAquaRadioButtonGroup.js';
import Tandem from '../../../../tandem/js/Tandem.js';
import ForcesAndMotionBasicsFluent from '../../ForcesAndMotionBasicsFluent.js';

export default class PullerColorControl extends VBox {

  public constructor( netForcePullerColorsProperty: StringUnionProperty<'blueRed' | 'purpleOrange'>, tandem: Tandem ) {

    const text = new Text( ForcesAndMotionBasicsFluent.netForcePullerColorsStringProperty, {
      font: PreferencesDialogConstants.PANEL_SECTION_LABEL_FONT,
      maxWidth: 500
    } );

    /**
     * Create an item for the radio button group.
     * @param value - value associated with the radio button
     * @param labelStringProperty - label that appears on the radio button
     */
    const createItem = ( value: 'blueRed' | 'purpleOrange', labelStringProperty: TReadOnlyProperty<string>, tandemName: string ) => {
      return {
        value: value,
        tandemName: tandemName,
        createNode: () => new Text( labelStringProperty, {
          font: PreferencesDialogConstants.CONTENT_FONT,
          maxWidth: 500
        } ),
        options: {
          accessibleName: labelStringProperty
        }
      };
    };

    // Items that describe the radio buttons
    const items = [
      createItem(
        'blueRed',
        ForcesAndMotionBasicsFluent.blueAndRedStringProperty,
        'blueRedRadioButton'
      ),
      createItem(
        'purpleOrange',
        ForcesAndMotionBasicsFluent.purpleAndOrangeStringProperty,
        'purpleOrangeRadioButton'
      )
    ];

    const radioButtonGroup = new VerticalAquaRadioButtonGroup( netForcePullerColorsProperty, items, {

      // pdom
      accessibleName: ForcesAndMotionBasicsFluent.netForcePullerColorsStringProperty,
      accessibleHelpText: ForcesAndMotionBasicsFluent.a11y.preferences.netForcePullerColorControl.accessibleHelpTextStringProperty,
      tandem: tandem.createTandem( 'radioButtonGroup' )
    } );

    super( {
      children: [ text, radioButtonGroup ],
      spacing: 8,
      align: 'center',
      isDisposable: false,
      tandem: tandem,
      phetioFeatured: true,
      visiblePropertyOptions: {
        phetioFeatured: true
      }
    } );

    this.addLinkedElement( netForcePullerColorsProperty );
  }
}
