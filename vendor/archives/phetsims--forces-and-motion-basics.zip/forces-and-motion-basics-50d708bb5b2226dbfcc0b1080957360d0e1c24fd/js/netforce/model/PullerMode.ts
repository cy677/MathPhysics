// Copyright 2025-2026, University of Colorado Boulder

/**
 * PullerMode represents the various states a puller can be in during the simulation.
 * This includes home position, being grabbed (by pointer or keyboard), and being attached to a knot.
 *
 * Tracking the grab method allows the model and view to differentiate pointer drags (continuous dragging and spatial
 * highlighting) from keyboard grabs (focus-driven navigation and cue nodes). Additional input devices should map to one
 * of these cases; if a unique behaviour is required, extend {@link GrabMethod} with a new entry and update the helper
 * predicates accordingly.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 */

import affirm from '../../../../perennial-alias/js/browser-and-node/affirm.js';
import IOType from '../../../../tandem/js/types/IOType.js';
import NullableIO from '../../../../tandem/js/types/NullableIO.js';
import NumberIO from '../../../../tandem/js/types/NumberIO.js';
import Knot from './Knot.js';
import NetForceModel from './NetForceModel.js';

type PullerModeType = 'home' | 'grabbed' | 'attached';
type GrabMethod = 'pointer' | 'keyboard';

type PullerModeOptions = {
  method?: GrabMethod;
  knotIndex?: number;
  overHome?: boolean;
};

export default class PullerMode {
  private readonly type: PullerModeType;
  private readonly method?: GrabMethod;
  private readonly knotIndex?: number;
  private readonly overHome?: boolean;

  private static readonly HOME_MODE = new PullerMode( 'home' );
  private static readonly POINTER_GRABBED_MODE = new PullerMode( 'grabbed', { method: 'pointer' } );
  private static readonly KEYBOARD_GRABBED_OVER_HOME_MODE = new PullerMode( 'grabbed', { method: 'keyboard', overHome: true } );

  private constructor( type: PullerModeType, options?: PullerModeOptions ) {
    this.type = type;
    this.method = options?.method;
    this.knotIndex = options?.knotIndex;
    this.overHome = options?.overHome;
  }

  public static home(): PullerMode {
    return PullerMode.HOME_MODE;
  }

  public static pointerGrabbed(): PullerMode {
    return PullerMode.POINTER_GRABBED_MODE;
  }

  public static keyboardGrabbedOverHome(): PullerMode {
    return PullerMode.KEYBOARD_GRABBED_OVER_HOME_MODE;
  }

  public static keyboardGrabbedOverKnot( knotIndex: number ): PullerMode {
    affirm( knotIndex >= 0 && knotIndex <= 7, `knotIndex must be 0-7 for absolute indexing, got ${knotIndex}` );
    return new PullerMode( 'grabbed', { method: 'keyboard', knotIndex: knotIndex } );
  }

  public static attachedToKnot( knotIndex: number ): PullerMode {
    affirm( knotIndex >= 0 && knotIndex <= 7, `knotIndex must be 0-7 for absolute indexing, got ${knotIndex}` );
    return new PullerMode( 'attached', { knotIndex: knotIndex } );
  }

  public isHome(): boolean {
    return this.type === 'home';
  }

  public isGrabbed(): boolean {
    return this.type === 'grabbed';
  }

  public isAttached(): boolean {
    return this.type === 'attached';
  }

  public isPointerGrabbed(): boolean {
    return this.type === 'grabbed' && this.method === 'pointer';
  }

  public isKeyboardGrabbed(): boolean {
    return this.type === 'grabbed' && this.method === 'keyboard';
  }

  public isKeyboardGrabbedOverHome(): boolean {
    return this.type === 'grabbed' && this.method === 'keyboard' && this.overHome === true;
  }

  public isKeyboardGrabbedOverKnot(): boolean {
    return this.type === 'grabbed' && this.method === 'keyboard' && this.knotIndex !== undefined;
  }

  public isKeyboardGrabbedOverSpecificKnot( knot: Knot, model: NetForceModel ): boolean {
    if ( !this.isKeyboardGrabbedOverKnot() ) {
      return false;
    }

    // Get the knot from the mode's stored index
    const modeKnot = this.getKnot( model );

    // Check if it's the same knot
    return modeKnot === knot;
  }

  public getKeyboardGrabbedKnotIndex(): number | null {
    if ( this.type === 'grabbed' && this.method === 'keyboard' && this.knotIndex !== undefined ) {
      return this.knotIndex;
    }
    return null;
  }

  public getAttachedKnotIndex(): number | null {
    if ( this.type === 'attached' && this.knotIndex !== undefined ) {
      return this.knotIndex;
    }
    return null;
  }

  public equals( other: PullerMode ): boolean {
    return this.type === other.type &&
           this.method === other.method &&
           this.knotIndex === other.knotIndex &&
           this.overHome === other.overHome;
  }

  public getKnot( model: NetForceModel ): Knot | null {
    const knotIndex = this.knotIndex;

    if ( knotIndex !== null && knotIndex !== undefined ) {
      affirm( knotIndex >= 0 && knotIndex <= 7, `knotIndex must be 0-7 for absolute indexing, got ${knotIndex}` );
      const knot = model.knots[ knotIndex ];
      affirm( knot !== undefined, `Knot index ${knotIndex} is out of bounds` );
      return knot;
    }
    else {
      return null;
    }
  }

  public static readonly PullerModeIO = new IOType<PullerMode, PullerModeState>( 'PullerModeIO', {
    valueType: PullerMode,
    stateSchema: {
      knot: NullableIO( NumberIO )
    },
    toStateObject: pullerMode => {
      return {
        knot: pullerMode.getAttachedKnotIndex()
      };
    },
    fromStateObject: stateObject => {
      if ( stateObject.knot === null ) {
        return PullerMode.home();
      }
      else {
        return PullerMode.attachedToKnot( stateObject.knot );
      }
    }
  } );
}

type PullerModeState = {
  knot: number | null;
};
