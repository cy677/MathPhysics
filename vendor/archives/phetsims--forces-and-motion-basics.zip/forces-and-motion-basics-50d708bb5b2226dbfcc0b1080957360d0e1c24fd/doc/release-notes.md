# Forces and Motion: Basics - Release Notes
<!-- 
Instructions:
* Replace {{SIM_TITLE}} with the simulation title.
* Replace {{VERSION}} with the version number, in MAJOR.MINOR format, e.g. "1.2".
* For a published version, replace {{PUBLICATION_DATE}} with the publication date, in year-month-day format, e.g. "2025-05-16".
* For a version that has not been published yet, replace {{PUBLICATION_DATE}} with "in progress".
* For a 1.0 release, only the 1.0 heading and date is needed. This includes ports of legacy sims.
* Developer and designer should collaborate on what to include for any release beyond 1.0. 
* For each new version, add a section to the top of these release notes - reverse chronological order, with the most-recent version at the top.

For an exemplar, see https://github.com/phetsims/balancing-chemical-equations/blob/main/doc/release-notes.md
-->

## 2.6 (2025-11-03)

### New Features
* Alternative Input
* Interactive Highlights: see _Preferences > Visual > Interactive Highlights_
* Core Description

### Changes
* Improved color contrast

## 2.5 (2025-06-23)

### New Features
* PhET-iO support, including PhET Studio

### Changes
* The value for gravity has been changed from 10 to 9.8 m/s<sup>2</sup>
  
## 2.4 (2024-12-13)

### New Features
* region and culture
* puller color preference and query parameter
* dynamic locale
* Basic Sound
